const numeroWhatsApp = "22394303664";

const boutons = document.querySelectorAll(".ajouter");

boutons.forEach(function(bouton) {

    bouton.addEventListener("click", function() {

        const produit = bouton.dataset.produit;
        const prix = Number(bouton.dataset.prix);

        const prixFormate = prix.toLocaleString("fr-FR");

        const message =
            "Bonjour CHEAP GAMING !\n\n" +
            "Je souhaite commander : " + produit + "\n" +
            "Prix : " + prixFormate + " FCFA\n\n" +
            "Merci de confirmer la disponibilité, " +
            "la compatibilité régionale et les modalités de paiement.";

        const lien =
            "https://wa.me/" + numeroWhatsApp +
            "?text=" + encodeURIComponent(message);

        window.open(lien, "_blank");

    });

});
